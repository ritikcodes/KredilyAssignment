import React from "react";
import TableCell from "./TableCell/TableCell";
import "./Table.css";

export default function Table({ tableHeads, tableRows, data }) {
  return (
    <div className="table" role="table">
      <div className="table-head">
        {tableHeads.map((columnName) => (
          <TableCell key={columnName}>{columnName}</TableCell>
        ))}
      </div>
      {data.map((element) => (
        <div className="table-row" key={element.name}>
          {tableRows.map((row) => {
            return (
              <TableCell key={element[row]} className={row.className}>
                {element[row]}
              </TableCell>
            );
          })}
        </div>
      ))}
    </div>
  );
}
