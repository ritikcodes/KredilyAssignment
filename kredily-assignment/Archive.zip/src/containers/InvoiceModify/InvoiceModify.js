import React, { useContext, useState } from "react";
import InputTextToggler from "../../components/InputTextToggler/InputTextToggler";
import SelectTextToggler from "../../components/SelectTextToggler/SelectTextToggler";
import TextareaToggler from "../../components/TextareaToggler/TextareaToggler";
import { appRoutes } from "../../constants/constants";
import { InvoiceContext } from "../../context/centralContext";
import "./InvoiceModify.css";

export default function InvoiceModify({ history }) {
  const [isEditModeEnabled, setIsEditModeEnabled] = useState(true);
  const [expenses, setExpenses] = useState([]);
  const { data, pushInvoice } = useContext(InvoiceContext);
  const [generatedOn, setGeneratedOn] = useState(
    new Date().toLocaleDateString()
  );

  function onExpenseChange(e, index) {
    let nextExpenses = [...expenses];
    nextExpenses[index] = { ...nextExpenses[index], id: e.target.value };
    return setExpenses(nextExpenses);
  }

  function onExpenseRateChange(e, index) {
    let nextExpenses = [...expenses];
    nextExpenses[index] = { ...nextExpenses[index], rate: e.target.value };
    return setExpenses(nextExpenses);
  }

  function onNoteChangeHandler(e) {}

  function onCreateInvoiceHandler() {
    pushInvoice({
      name: "Invoice 3",
      per_hour_rate: 10,
      hours_spent: 100,
      invoice_value: 1000,
      notes: "",
      client_email: "mailcritik@gmail.com",
      status: "pending",
      due_date: 1697999400000,
    });
    history.push(appRoutes.invoices_list);
  }

  return (
    <section>
      <div className="invoice-modify">
        <button
          onClick={() =>
            setIsEditModeEnabled((isEditModeEnabled) => !isEditModeEnabled)
          }
        >
          toggle
        </button>
        <div className="invoice-head">
          <h1>Invoice</h1>
          <span>
            Generated on :
            <InputTextToggler
              textOnly={!isEditModeEnabled}
              value={generatedOn}
              type="date"
            />
          </span>
        </div>
        <div className="invoice-details">
          <h3>Invoice Details :</h3>
          <hr />

          <div className="invoice-details__expenses">
            {expenses.map((ele, index) => {
              return (
                <div>
                  <SelectTextToggler
                    onChange={(e) => onExpenseChange(e, index)}
                    defaultValue={ele.id}
                    textOnly={!isEditModeEnabled}
                  />

                  <InputTextToggler
                    onChange={(e) => onExpenseRateChange(e, index)}
                    textOnly={!isEditModeEnabled}
                    type="text"
                    value={ele.rate}
                    placeholder="Enter charges"
                  />
                </div>
              );
            })}
          </div>
          <button
            onClick={function () {
              setExpenses([...expenses, { id: "1", rate: "" }]);
            }}
          >
            Add expense
          </button>
          <div className="invoice-details__notes">
            <TextareaToggler
              placeholder="Enter notes"
              onChange={onNoteChangeHandler}
            />
          </div>
        </div>
      </div>
      <div className="invoice-modify__btns">
        <button onClick={onCreateInvoiceHandler}>Create invoice</button>
      </div>
    </section>
  );
}
