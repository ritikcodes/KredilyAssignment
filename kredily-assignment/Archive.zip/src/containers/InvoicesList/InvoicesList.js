import React, { useContext, useState } from "react";
import { Link } from "react-router-dom";
import Table from "../../components/Table/Table";
import { appRoutes, appTexts } from "../../constants/constants";
import { InvoiceContext } from "../../context/centralContext";
import "./InvoicesList.css";

export default function InvoicesList() {
  const { data } = useContext(InvoiceContext);

  const columnsHead = appTexts.invoices_list.table_heads;
  const tableRowsKeys = [
    "name",
    "per_hour_rate",
    "hours_spent",
    "invoice_value",
    "status",
  ];

  return (
    <div className="invoices-list">
      <div className="invoices-list__btn">
        <Link to={appRoutes.create_invoice}>
          <button>{appTexts.invoices_list.page_title}</button>
        </Link>
      </div>
      <Table data={data} tableHeads={columnsHead} tableRows={tableRowsKeys} />
    </div>
  );
}
