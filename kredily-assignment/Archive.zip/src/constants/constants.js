import InvoiceModify from "../containers/InvoiceModify/InvoiceModify";
import InvoicesList from "../containers/InvoicesList/InvoicesList";

export const appTexts = {
  app_name: "Invoice generator",
  invoices_list: {
    page_title: "Create invoice",
    table_heads: [
      "Name",
      "Per hour rate",
      "Hours spent",
      "Invoice value",
      "Status",
    ],
  },
};

export const appRoutes = {
  invoices_list: "/",
  create_invoice: "/create-invoice",
};

export const appRoutesMappedWithComponents = [
  { path: appRoutes.invoices_list, component: <InvoicesList /> },
  { path: appRoutes.create_invoice, component: <InvoiceModify /> },
];
