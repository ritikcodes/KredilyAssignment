import React from "react";

export const InvoiceContext = React.createContext();
