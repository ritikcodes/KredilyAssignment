import { Routes, Route, BrowserRouter } from "react-router-dom";
import { appRoutesMappedWithComponents, appTexts } from "./constants/constants";
import "./App.css";
import { InvoiceContext } from "./context/centralContext";
import { useState } from "react";

function App() {
  const [data, setData] = useState([
    {
      name: "Invoice 1",
      per_hour_rate: 10,
      hours_spent: 100,
      invoice_value: 1000,
      notes: "",
      client_email: "mailcritik@gmail.com",
      status: "pending",
      due_date: 1666463400000,
    },
    {
      name: "Invoice 2",
      per_hour_rate: 10,
      hours_spent: 100,
      invoice_value: 1000,
      notes: "",
      client_email: "mailcritik@gmail.com",
      status: "pending",
      due_date: 1697999400000,
    },
  ]);

  function pushInvoice(newInvoice) {
    return setData([...data, newInvoice]);
  }

  return (
    <InvoiceContext.Provider value={{ data, pushInvoice }}>
      <BrowserRouter>
        <div className="App">
          <h1>{appTexts.app_name}</h1>
          <Routes>
            {appRoutesMappedWithComponents.map((element) => {
              return (
                <Route
                  path={element.path}
                  element={element.component}
                  key={element.path}
                />
              );
            })}
          </Routes>
        </div>
      </BrowserRouter>
    </InvoiceContext.Provider>
  );
}

export default App;
